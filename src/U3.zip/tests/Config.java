package tests;

/**
 * Test config
 *
 * @author Jimmy Lindström (ae7220)
 * @author Andreas Indal (ae2922)
 */
public class Config {
    public final static String PATH  = "/Users/andreas/code/java/image-compression/src/resources/";
    public final static String IMAGE = "green_boat";
}
