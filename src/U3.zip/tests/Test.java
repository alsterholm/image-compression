package tests;

/**
 * Test class
 *
 * @author Jimmy Lindström (ae7220)
 * @author Andreas Indal (ae2922)
 */
public class Test {
    public static void main(String[] args) {
        TestMTG2BCI.main(args);
        TestBCI2MTG.main(args);
        TestMTG2PNG.main(args);
    }
}
